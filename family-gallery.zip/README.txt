The Signal — family gallery photos (8 images)

These JPEGs were resized for the web and original EXIF/location metadata stripped.
In the public repository FREEfadi/the-signal-audio, upload the eight JPGs into the photos/ folder with their exact filenames.
The public website will automatically show all eight on the next successful GitHub Pages deployment.

Important: The public website means these photos are visible and downloadable by anyone with the site URL.
